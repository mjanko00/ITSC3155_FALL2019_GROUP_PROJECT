class Journal < ApplicationRecord
end
